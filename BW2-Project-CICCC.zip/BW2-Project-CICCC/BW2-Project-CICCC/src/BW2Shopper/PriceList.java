package BW2Shopper;

import java.util.Scanner;

public class PriceList {

	public void checkPriceList() {
		Scanner input = new Scanner(System.in);
		System.out.println("\nWhich PriceList would you like see: \n");
		System.out.println("01 - MODEL");
		System.out.println("02 - PARTS\n");

		int category = input.nextInt();
		if (category == 1) {
			System.out.println("#######------- PRICE LIST -------#######\n");
			String[][] data = { { "Car Model", "Basic Price" }, { "Velar\t", "$30,000" }, { "Discovery", "$40,000" },
					{ "Defender", "$50,000" } };
			for (int i = 0; i < data.length; i++) {
				for (int j = 0; j < data[j].length; j++) {
					System.out.print("|" + data[i][j] + '\t');
				}
				System.out.println("|");
			}
		} else if (category == 2) {
			System.out.println("#######------- PRICE LIST -------#######\n");
			System.out.println("01 - WHEEL");
			System.out.println("02 - AIR CONDITION");
			System.out.println("03 - MOTOR");
			System.out.println("04 - DASHBOARD SYSTEM");
			System.out.println("05 - PACK SAFETY");
			System.out.println("06 - EXTRA OPTIONS");

			int parts = input.nextInt();
			if (parts == 1) {
				System.out.println("#######------- PRICE LIST -------#######\n");
				String[][] data = { { "Wheels", "Add Price" }, { "17'", "$1,000\t" }, { "19'", "$1,200\t" },
						{ "21'", "$1,500\t" } };
				for (int i = 0; i < data.length; i++) {
					for (int j = 0; j < data[j].length; j++) {
						System.out.print("|" + data[i][j] + '\t');
					}
					System.out.println("|");
				}
			} else if (parts == 2) {
				System.out.println("#######------- PRICE LIST -------#######\n");
				String[][] data = { { "Air condition", "Add Price" }, { "Dual zone", "$1,000\t" },
						{ "Quad zone", "$1,200\t" }, { "Multi zone", "$1,500\t" } };
				for (int i = 0; i < data.length; i++) {
					for (int j = 0; j < data[j].length; j++) {
						System.out.print("|" + data[i][j] + '\t');
					}
					System.out.println("|");
				}
			} else if (parts == 3) {
				System.out.println("#######------- PRICE LIST -------#######\n");
				String[][] data = { { "Motor\t\t", "Add Price" }, { "2.0turbo charge", "$1,000\t" },
						{ "3.5turbo charge", "$1,200\t" }, { "4.5turbo charge", "$1,500\t" } };
				for (int i = 0; i < data.length; i++) {
					for (int j = 0; j < data[j].length; j++) {
						System.out.print("|" + data[i][j] + '\t');
					}
					System.out.println("|");
				}
			} else if (parts == 4) {
				System.out.println("#######------- PRICE LIST -------#######\n");
				String[][] data = { { "Dashbord system", "Add Price" }, { "Incontrol\t", "$1,000\t" },
						{ "Touch Pro\t", "$1,200\t" }, { "Touch Pro+\t", "$1,500\t" } };
				for (int i = 0; i < data.length; i++) {
					for (int j = 0; j < data[j].length; j++) {
						System.out.print("|" + data[i][j] + '\t');
					}
					System.out.println("|");
				}
			} else if (parts == 5) {
				System.out.println("#######------- PRICE LIST -------#######\n");
				String[][] data = { { "Pack safety", "Add Price" }, { "Basic\t", "$1,000\t" },
						{ "Advance", "$1,200\t" }, { "Prime\t", "$1,500\t" } };
				for (int i = 0; i < data.length; i++) {
					for (int j = 0; j < data[j].length; j++) {
						System.out.print("|" + data[i][j] + '\t');
					}
					System.out.println("|");
				}
			} else if (parts == 6) {
				System.out.println("#######------- PRICE LIST -------#######\n");
				String[][] data = { { "Extro option\t\t", "Add Price" }, { "Interavtive Driver Display", "$1,000\t" },
						{ "360 Parking Aid\t", "$1,100\t" }, { "On-road Performance\t", "$1,200\t" },
						{ "Full-road Performance\t", "$1,300\t" } };
				for (int i = 0; i < data.length; i++) {
					for (int j = 0; j < data[j].length; j++) {
						System.out.print("|" + data[i][j] + '\t');
					}
					System.out.println("|");
				}
			} else {
				System.out.println("\nPlease just select one of the options above!");
			}
		} else {
			System.out.println("\nPlease just select one of the options above!");
		}

	}
}
