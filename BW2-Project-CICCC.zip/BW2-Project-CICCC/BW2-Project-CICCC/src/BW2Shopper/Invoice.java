package BW2Shopper;

import java.util.HashMap;

public class Invoice extends SelectProduct {

	public void calculateInvoice() {
		HashMap<String, Integer> map = new HashMap<String, Integer>();
		///// Price of Model//////
		map.put("LandRover Velar", 30000);
		map.put("LandRover Discovery", 40000);
		map.put("LandRover Defender", 50000);

		///// Price of Parts/////
		// Wheels//
		map.put("17", 1000);
		map.put("19", 1200);
		map.put("21", 1500);
		// Air Condition//
		map.put("dual zone", 1000);
		map.put("quad zone", 1200);
		map.put("multi zone", 1500);
		// Motor//
		map.put("2.0 Turbo Charger", 1000);
		map.put("3.5 Turbo Charger", 1200);
		map.put("4.5 Turbo Charger", 1500);
		// Dash board//
		map.put("Incontrol", 1000);
		map.put("Touch Pro", 1200);
		map.put("Touch Pro + Audio system 'Meridia'", 1500);
		// Pack Safety//
		map.put("basic", 1000);
		map.put("advance", 1200);
		map.put("prime", 1500);

		///// Extra option/////
		map.put("Interactive Driver Display", 1000);
		map.put("360 Parking Aid", 1100);
		map.put("On-road Perfomance", 1200);
		map.put("Full-road Perfomance", 1300);

		int carModelPrice;
		int wheelsPrice;
		int airConditionPrice;
		int motorPrice;
		int dashboardSystemPrice;
		int packSafetyPrice;
		int extraOptionPrice = 0;

		for (String element : Cars.extraOption) {
			if (element.equals("Interactive Driver Display")) {
				extraOptionPrice += map.get("Interactive Driver Display");
			} else if (element.equals("360 Parking Aid")) {
				extraOptionPrice += map.get("360 Parking Aid");
			} else if (element.equals("On-road Perfomance")) {
				extraOptionPrice += map.get("On-road Perfomance");
			} else if (element.equals("Full-road Perfomance")) {
				extraOptionPrice += map.get("Full-road Perfomance");
			} else {
				extraOptionPrice = 0;
			}
		}

		// Price of carModel//
		if (carModel == "LandRover Velar") {
			carModelPrice = map.get("LandRover Velar");
		} else if (carModel == "LandRover Discovery") {
			carModelPrice = map.get("LandRover Discovery");
		} else if (carModel == "LandRover Defender") {
			carModelPrice = map.get("LandRover Defender");
		} else {
			carModelPrice = 0;
		}

		// Price of wheels//
		if (wheels == "17") {
			wheelsPrice = map.get("17");
		} else if (wheels == "19") {
			wheelsPrice = map.get("19");
		} else if (wheels == "21") {
			wheelsPrice = map.get("21");
		} else {
			wheelsPrice = 0;
		}
		// Price of airCondition//
		if (airCondition == "dual zone") {
			airConditionPrice = map.get("dual zone");
		} else if (airCondition == "quad zone") {
			airConditionPrice = map.get("quad zone");
		} else if (airCondition == "multi zone") {
			airConditionPrice = map.get("multi zone");
		} else {
			airConditionPrice = 0;
		}
		// Price of motor
		if (motor == "2.0 Turbo Charger") {
			motorPrice = map.get("2.0 Turbo Charger");
		} else if (motor == "3.5 Turbo Charger") {
			motorPrice = map.get("3.5 Turbo Charger");
		} else if (motor == "4.5 Turbo Charger") {
			motorPrice = map.get("4.5 Turbo Charger");
		} else {
			motorPrice = 0;
		}

		// Price of DashBoard//
		if (dashboardSystem == "Incontrol") {
			dashboardSystemPrice = map.get("Incontrol");
		} else if (dashboardSystem == "Touch Pro") {
			dashboardSystemPrice = map.get("Touch Pro");
		} else if (dashboardSystem == "Touch Pro + Audio system 'Meridia'") {
			dashboardSystemPrice = map.get("Touch Pro + Audio system 'Meridia'");
		} else {
			dashboardSystemPrice = 0;
		}

		// Price of pack safety//
		if (packSafety == "basic") {
			packSafetyPrice = map.get("basic");
		} else if (packSafety == "advance") {
			packSafetyPrice = map.get("advance");
		} else if (packSafety == "prime") {
			packSafetyPrice = map.get("prime");
		} else {
			packSafetyPrice = 0;
		}

		int total = carModelPrice + motorPrice + airConditionPrice + dashboardSystemPrice + packSafetyPrice
				+ extraOptionPrice;

		System.out.println("\n");
		System.out.println("###Invoice###");
		System.out.printf(carModel + ": $%,d%n", carModelPrice);
		System.out.printf(motor + ": $%,d%n", motorPrice);
		System.out.printf(wheels + "inch wheels: $%,d%n", wheelsPrice);
		System.out.printf(airCondition + ": $%,d%n", airConditionPrice);
		System.out.printf(dashboardSystem + ": $%,d%n", dashboardSystemPrice);
		System.out.printf(packSafety + ": $%,d%n", packSafetyPrice);
		System.out.printf(extraOption + ": $%,d%n", extraOptionPrice);
		System.out.println("-------------------------------------");
		System.out.printf("Total: $%,d", total);
		System.out.println("\n");

	}

}