package BW2Shopper;

import java.util.HashMap;
import java.util.Scanner;

public class User extends Menu {

	private static String userName = "";
	private static String passWord = "";
	private String registry;
	private static int userId;
//	private boolean login;

	protected String temp;
	protected String tempUserName;
	protected String tempPassword;
	protected String tempRegistry;

	Scanner input = new Scanner(System.in);

	public void Login() {

		System.out.println("\n#######--------BW2SHOPPER SYTEM------########\n");
		System.out.println("Hello, for you have access you need to have userID valid or you need create a new one.\n");
		System.out.println("For you type your userID choice: \n");
		System.out.println("01 - LOGIN");
		System.out.println("02 - SING UP\n");
		temp = input.next();

		if (temp.equals("01") || (temp.equals("1"))) {
			checkUser();
		} else if (temp.equals("02") || (temp.equals("2"))) {
			createUser();
		} else {
			System.out.println("Sorry, but for you use this system you need choice just available option above");
			Login();
		}

	}

	public void checkUser() {
		System.out.println("\n######------ CHECK USER ------######");
		System.out.println("\nPlease type your username: ");
		this.tempUserName = input.next();
		System.out.println("Type your password: ");
		this.tempPassword = input.next();

		if (this.getUserName().equals(tempUserName) & this.getPassWord().equals(tempPassword)) {
			System.out.println("\n############--------- WELCOME BW2SHOPPER " + this.getUserName().toUpperCase()
					+ (" --------##########"));
//			this.setLogin(true);
		} else {
			System.out.println("\nSorry but your user name or password is wrong!\n");
			System.out.println("Would you like to try again, type YES or NO");
			if (input.next().toLowerCase().contentEquals("yes")) {
				checkUser();
			} else {
				Login();
			}

		}
	}

	public void createUser() {
		userId = (int) (Math.random() * 9999 + 1000);
		System.out.println("\nChoice your username: ");
		User.userName = input.next();
		registerNumber();
		createPassword();
		System.out.println("\nYour user is created and your user ID is: " + "'" + this.getUserId() + "' !");
		checkUser();
//		this.setLogin(true);
	}

	public void registerNumber() {
		HashMap<String, String> map = new HashMap<String, String>();
		map.put("1236", "Tugba");
		map.put("1245", "Fernando");
		map.put("1225", "Hiro");
		map.put("1230", "Shinya");

		System.out.println("\nType your register number: ");
		registry = input.next();

		if (!map.containsKey(registry)) {
			System.out.println("Sorry but you no allowed to access this system!");
			System.out.println(
					"\nWould you like to see the list that have the names allowed access this system,  YES or NO!");
			tempRegistry = input.next().toLowerCase();
			if (tempRegistry.equals("yes") || tempRegistry.equals("ye") || tempRegistry.equals("y")
					|| tempRegistry.equals("ys")) {
				System.out.println(map.values());
				registerNumber();

			}
		}

	}

	public void createPassword() {

		Scanner input = new Scanner(System.in);
		System.out.println("\nPlease type your password: ");
		System.out.println(
				"\nBe careful your PASSWORD must be number and letter and must have at least eight characters or not must contain white spaces :");
		User.passWord = input.next();

		int lenght = passWord.length();
		int digit = 0;

		for (int i = 0; i < lenght; i++) {
			char chr = passWord.charAt(i);

			if (Character.isDigit(chr) || Character.isLetter(chr)) {
				if (Character.isDigit(chr)) {
					digit += 1;
				}
			} else {
				System.out.println("Please type only letters and digits for your password");
				createPassword();
			}
		}

		if (lenght < 8) {
			System.out.println(
					"Sorry, but your password must have at least eight characters or not must contain white spaces\n");
			createPassword();
		} else if (digit < 2) {
			System.out.println("Sorry, but your password must contain at least two digits ");
			createPassword();
		} else {
			System.out.println("\nYour username is: '" + this.getUserName() + "' and your password is: '"
					+ this.getPassWord() + "' and it was saved");
		}

	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		User.userName = userName;
	}

	public String getPassWord() {
		return passWord;
	}

	public void setPassWord(String passWord) {
		User.passWord = passWord;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		User.userId = userId;
	}

	public String getRegistry() {
		return registry;
	}

	public void setRegistry(String registry) {
		this.registry = registry;
	}

//	public boolean getLogin() {
//		return login;
//	}
//
//	public void setLogin(boolean login) {
//		this.login = login;
//	}

}
