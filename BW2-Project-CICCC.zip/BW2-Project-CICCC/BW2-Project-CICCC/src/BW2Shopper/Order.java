package BW2Shopper;

import java.util.Scanner;

public class Order {

	protected static int idOrder = 0;
	protected int salesId;
	protected static boolean statusOrder;
	protected String temp;
	protected int answer;

	private static String customerName;
	private static String customerEmail;
	private static String customerAddress;

	Scanner input = new Scanner(System.in);

	public void callOrder() {
		System.out.println("\n01 - CREATE ORDER");
		System.out.println("02 - CANCEL ORDER");
		System.out.println("03 - CHECK ORDER");
		answer = input.nextInt();

		if (answer == 01) {
			createOrder();
		} else if (answer == 02) {
			cancelOrder();
		} else if (answer == 03) {
			checkOrder();
		} else {
			System.out.println("\n Sorry but you need choice just the option available");
		}

	}

	public void createOrder() {

		User obj = new User();
		salesId = obj.getUserId();
		statusOrder = true;
		idOrder += 1;

		System.out.println("\nType customer name: ");
		temp = input.next();
		this.setCustomerName(temp);

		System.out.println("Type customer address: ");
		temp = input.next();
		this.setCustomerAddress(temp);

		System.out.println("Type customer email: ");
		temp = input.next();
		this.setCustomerEmail(temp);

		checkOrder();

	}

	public void cancelOrder() {
		temp = "";
		this.setCustomerName(temp);
		this.setCustomerAddress(temp);
		this.setCustomerEmail(temp);
		statusOrder = false;
	}

	public void checkOrder() {
		if (statusOrder == true) {
			User obj = new User();
			salesId = obj.getUserId();
			System.out.println("\n#########-----STATUS-----#########");
			System.out.println("The number ID - order: " + idOrder);
			System.out.println("The salesId: " + salesId);
//			System.out.println("\n");
			System.out.println("########-----CLIENT'S DATA-----######");
			System.out.println("Name: " + this.getCustomerName());
			System.out.println("Address: " + this.getCustomerAddress());
			System.out.println("E-mail: " + this.getCustomerEmail());
		} else {
			System.out.println("\nThere ins't order created");
		}
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		Order.customerName = customerName;
	}

	public String getCustomerEmail() {
		return customerEmail;
	}

	public void setCustomerEmail(String customerEmail) {
		Order.customerEmail = customerEmail;
	}

	public String getCustomerAddress() {
		return customerAddress;
	}

	public void setCustomerAddress(String customerAddress) {
		Order.customerAddress = customerAddress;
	}

}
