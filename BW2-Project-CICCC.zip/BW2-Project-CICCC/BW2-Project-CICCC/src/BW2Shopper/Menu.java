package BW2Shopper;

import java.util.Scanner;

public class Menu extends Order {

	public void menu() {

		Scanner input = new Scanner(System.in);
		int temp = 0;

		while (temp != 5) {
			System.out.println("\n########-------- MENU BW2SHOPPER SYSTEM --------#########");
			System.out.println(" \n01 - CHECK PRICE.");
			System.out.println("02 - SELECT PRODUCT.");
			System.out.println("03 - ORDER.");
			System.out.println("04 - INVOICE.");
			System.out.println("05 - PRINT.");
			System.out.println("06 - LOG OFF.");
			System.out.println("07 - EXIT");
			System.out.println("\nPlease select one of the options above ");
			temp = input.nextInt();

			PriceList objPrice = new PriceList();
			SelectProduct objProduct = new SelectProduct();
			Invoice objInvoice = new Invoice();
			Order objOrder = new Order();
			User objUser = new User();

			if (temp == 01) {
				objPrice.checkPriceList();
			} else if (temp == 02) {
				objProduct.selectCar();
			} else if (temp == 03) {
				this.callOrder();
			} else if (temp == 04) {
				objInvoice.calculateInvoice();
			} else if (temp == 05) {
				if (Order.statusOrder & SelectProduct.statusCar) {
					objOrder.checkOrder();
					objInvoice.calculateInvoice();
					menu();
				} else {
					System.out.println("Sorry you can not PRINT without you create ORDER! ");
					menu();
				}
			} else if (temp == 06) {
				objUser.Login();
			} else if (temp == 07) {
				System.exit(1);
			} else {
				System.out.println("\n Sorry but you need choice just the option available");
			}
		}
	}
}
