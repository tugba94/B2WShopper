package BW2Shopper;

import java.util.Scanner;

public class SelectProduct extends Cars {

	protected int model;
	protected int category;
	protected int color;
	protected int choose = 0;
	protected static boolean statusCar;
	protected String answer1;
	protected String answer2;
	protected String value = "";
	protected String optional = "";

	public void selectCar() {
		Scanner input = new Scanner(System.in);

		System.out.println("\nLet's purchase your car \n");
		System.out.println("We have three possibity to offer you! \n");
		System.out.println("#######---- LandRover Velar, LandRover Discovery, LandRover Defender ----###### \n");
		System.out.println("\nPlease type: ");
		System.out.println("\n0 - VELAR");
		System.out.println("1 - DISCOVERY");
		System.out.println("2 - DEFENDER");
		model = input.nextInt();
		while (model >= 3 || model < 0) {
			System.out.println("\n0 - VELAR");
			System.out.println("1 - DISCOVERY");
			System.out.println("2 - DEFENDER");
			System.out.println("\nPlease just select one of the option above");
			model = input.nextInt();
		}
		this.selectCarModel(model);

		System.out.println("Please select the category you would like: \n");
		System.out.println("0 - STANDARD");
		System.out.println("1 - SPORT");
		System.out.println("2 - LUXURY");
		category = input.nextInt();
		while (category >= 3 || category < 0) {
			System.out.println("0 - STANDARD");
			System.out.println("1 - SPORT");
			System.out.println("2 - LUXURY");
			System.out.println("\nPlease just select one of the option above");
			category = input.nextInt();
		}
		this.selectCategory(category);

		System.out.println("Please select the color you would like: ");
		System.out.println("\n0 - BLACK");
		System.out.println("1 - WHITE");
		System.out.println("2 - RED");
		System.out.println("3 - BLUE");
		System.out.println("4 - SILVER");
		color = input.nextInt();
		while (color >= 5 || color < 0) {
			System.out.println("\n0 - BLACK");
			System.out.println("1 - WHITE");
			System.out.println("2 - RED");
			System.out.println("3 - BLUE");
			System.out.println("4 - SILVER");
			System.out.println("\nPlease just select one of the option above");
			color = input.nextInt();
		}
		this.selectCarColor(color);

		System.out.println("\n");
		System.out.println("\nWould you still like to add 'EXTRA' options in your car?, YES or NO");
		answer1 = input.next().toLowerCase();

		while (answer1.equals("yes") || answer1.equals("ye") || answer1.equals("y")) {
			System.out.println("There are these options that you can select: ");
			System.out.println("\n0 - INTERACTIVE DRIVER DISPLAY");
			System.out.println("1 - 360 PARKING AID");
			System.out.println("2 - ON-ROAD PERFOMANCE");
			System.out.println("3 - FULL-ROAD PERFOMANCE");
			int extraOption = input.nextInt();

			if (extraOption == 0 || extraOption == 1 || extraOption == 2 || extraOption == 3) {
				this.selectExtraOption(extraOption);
			} else {
				System.out.println("\nSorry but you can not choose item unavailable");
			}

			System.out.println("\nWould you still like to add 'EXTRA' options in your car?, YES or NO");
			answer1 = input.next().toLowerCase();
		}
		this.carStatus();

		System.out.println("\nWould you like to change the 'BASIC' option in your car?, YES or NO");
		answer2 = input.next().toLowerCase();

		while (answer2.equals("yes") || answer2.equals("ye") || answer2.equals("y")) {
			System.out.println("Which accessory would you like to change: ");
			System.out.println("\n0 - MOTOR");
			System.out.println("1 - WHEELS");
			System.out.println("2 - AIR CONDITION");
			System.out.println("3 - DASHBOARD SYSTEM");
			System.out.println("4 - PACK SAFETY");
			System.out.println("5 - COLOR");
			int option = input.nextInt();

			if (option == 0) {
				System.out.println("Please type the motor you would like to change: ");
				System.out.println("\n0 - 2.0 TURBO CHARGE");
				System.out.println("1 - 3.5 TURBO CHARGE");
				System.out.println("2 - 4.5 TURBO CHARGE");
				choose = input.nextInt();
				optional = "motor";
				if (choose == 0) {
					value = "2.0 Turbo Charger";
				} else if (choose == 1) {
					value = "3.5 Turbo Charger";
				} else if (choose == 2) {
					value = "4.5 Turbo Charger";
				} else {
					System.out.println("Sorry, but you cannot change item without to be inside the list");
				}
				this.selectIndividualOption(optional, value);
				System.out.println("Would you like to change one more item?, YES or NO");
				answer2 = input.next().toLowerCase();
			} else if (option == 1) {
				System.out.println("Please type size wheels you would like to change: ");
				System.out.println("\n0 - 17");
				System.out.println("1 - 19");
				System.out.println("2 - 21");
				choose = input.nextInt();
				optional = "wheels";
				if (choose == 0) {
					value = "17";
				} else if (choose == 1) {
					value = "19";
				} else if (choose == 2) {
					value = "21";
				} else {
					System.out.println("Sorry, but you cannot change item without to be inside the list");
				}
				this.selectIndividualOption(optional, value);
				System.out.println("Would you like to change one more item?, YES or NO");
				answer2 = input.next().toLowerCase();
			} else if (option == 2) {
				System.out.println("\nPlease type airCondition you would like to change: ");
				System.out.println("\n0 - DUAL ZONE");
				System.out.println("1 - QUAD ZONE");
				System.out.println("2 - MULT ZONE");
				choose = input.nextInt();
				optional = "airCondition";
				if (choose == 0) {
					value = "dual zone";
				} else if (choose == 1) {
					value = "quad zone";
				} else if (choose == 2) {
					value = "mult zone";
				} else {
					System.out.println("Sorry, but you cannot change item without to be inside the list");
				}
				this.selectIndividualOption(optional, value);
				System.out.println("Would you like to change one more item?, YES or NO");
				answer2 = input.next().toLowerCase();
			} else if (option == 3) {
				System.out.println("\nPlease type dashboardSystem you would like to change: ");
				System.out.println("\n0 - INCONTROL");
				System.out.println("1 - TOUCH PRO");
				System.out.println("2 - TOUCH PRO + AUDIO SYSTEM 'MERIDIA'");
				choose = input.nextInt();
				optional = "dashboardSystem";
				if (choose == 0) {
					value = "Incontrol";
				} else if (choose == 1) {
					value = "Touch Pro";
				} else if (choose == 2) {
					value = "Touch Pro + Audio system 'Meridia'";
				} else {
					System.out.println("Sorry, but you cannot change item without to be inside the list");
				}
				this.selectIndividualOption(optional, value);
				System.out.println("Would you like to change one more item?, YES or NO");
				answer2 = input.next().toLowerCase();
			} else if (option == 4) {
				System.out.println("\nPlease type pack Safety you would like to change: ");
				System.out.println("\n0 - BASIC");
				System.out.println("1 - ADVANCE");
				System.out.println("2 - PRIME");
				choose = input.nextInt();
				optional = "packSafety";
				if (choose == 0) {
					value = "basic";
				} else if (choose == 1) {
					value = "adavance";
				} else if (choose == 2) {
					value = "prime";
				} else {
					System.out.println("Sorry, but you cannot change item without to be inside the list");
				}
				this.selectIndividualOption(optional, value);
				System.out.println("Would you like to change one more item?, YES or NO");
				answer2 = input.next().toLowerCase();
			} else if (option == 5) {
				System.out.println("\nPlease type witch color you would like to change: ");
				System.out.println("\n0 - BLACK");
				System.out.println("1 - WHITE");
				System.out.println("2 - RED");
				System.out.println("3 - BLUE");
				System.out.println("4 - SILVER");
				choose = input.nextInt();

				if (choose == 0 || choose == 1 || choose == 2 || choose == 3 || choose == 4) {
					this.selectCarColor(choose);
				} else {
					System.out.println("Sorry, but you cannot change item without to be inside the list");
				}
				System.out.println("\nWould you like to change one more item?, YES or NO");
				answer2 = input.next().toLowerCase();
			}

		}
		statusCar = true;
		this.carStatus();

	}

}
