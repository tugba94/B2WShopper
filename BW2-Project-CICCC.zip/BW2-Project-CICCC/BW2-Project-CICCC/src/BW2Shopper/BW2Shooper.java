package BW2Shopper;

public class BW2Shooper {

	public static void main(String[] args) {

		User guess = new User();
		guess.Login();
		guess.menu();

	}

}
