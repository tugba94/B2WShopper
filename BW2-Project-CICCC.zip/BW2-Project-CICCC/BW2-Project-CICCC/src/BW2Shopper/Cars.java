package BW2Shopper;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Cars {

	static String carModel;
	static String category;
	static String motor;
	static String wheels;
	static String airCondition;
	static String dashboardSystem;
	static String packSafety;
	static int carColor;

	static ArrayList<String> extraOption = new ArrayList<String>();

	List<String> carModels = Arrays.asList("LandRover Velar", "LandRover Discovery", "LandRover Defender");
	List<String> carCategory = Arrays.asList("Standart", "Sport", "Luxury");
	List<String> extraOptions = Arrays.asList("Interactive Driver Display", " 360 Parking Aid", "On-road Perfomance",
			"Full-Road Perfomance");
	List<String> selectColor = Arrays.asList("black", "white", "red", "blue", "silver");

	public void selectCarModel(int model) {
		for (int i = 0; i < carModels.size(); i++) {
			if (i == model)
				carModel = carModels.get(model);
		}
	}

	public void selectCategory(int option) {
		for (int i = 0; i < carCategory.size(); i++) {
			if (option == 0) {
				category = "Standart";
				wheels = "17";
				airCondition = "dual zone";
				motor = "2.0 Turbo Charger";
				dashboardSystem = "Incontrol";
				packSafety = "basic";
			} else if (option == 1) {
				category = "Sport";
				wheels = "19";
				airCondition = "quad zone";
				motor = "4.5 Turbo Charger";
				dashboardSystem = "Touch Pro";
				packSafety = "advance";
			} else if (option == 2) {
				category = "Luxury";
				wheels = "21";
				airCondition = "mult zone";
				motor = "3.5 Turbo Charger";
				dashboardSystem = "Touch Pro + Audio system 'Meridia' ";
				packSafety = "prime";
			} else {
				System.out.println("Sorry you need select one of the options above");
			}
		}
	}

	public void selectCarColor(int color) {
		for (int i = 0; i < selectColor.size(); i++) {
			if (i == color) {
				carColor = color;
			}
		}
	}

	public void selectExtraOption(int option) {
		if (option == 0) {
			extraOption.add("Interactive Driver Display");
		} else if (option == 1) {
			extraOption.add("360 Parking Aid");
		} else if (option == 2) {
			extraOption.add("On-road Perfomance");
		} else if (option == 3) {
			extraOption.add("Full-road Perfomance");
		} else {
			System.out.println("Sorry but you not can define unkown option");
		}
	}

	public void selectIndividualOption(String opt, String val) {
		if (opt == "motor") {
			motor = val;
		} else if (opt == "wheels") {
			wheels = val;
		} else if (opt == "airCondition") {
			airCondition = val;
		} else if (opt == "dashboardSystem") {
			dashboardSystem = val;
		} else if (opt == "packSafety") {
			packSafety = val;
		} else {
			System.out.println("Sorry, but you cannot add change an option without being on the basic list. ");
		}
	}

	public void carStatus() {
		System.out.println("\n");
		System.out.println("\n");
		System.out.println("The car select is: " + carModel);
		System.out.println("\n");
		System.out.println("###Main Features:###");
		System.out.println("Category: " + category);
		System.out.println("Motor: " + motor);
		System.out.println("Color: " + selectColor.get(carColor));
		System.out.println("Wheels: " + wheels);
		System.out.println("AirCondition: " + airCondition);
		System.out.println("DashboardSystem: " + dashboardSystem);
		System.out.println("Pack Safety: " + packSafety);
		System.out.println("Extra Options is: " + extraOption);
		System.out.println("\n");
		System.out.println("############-----------------#############");

	}

}
