package com.B2WShopper;

import java.util.Scanner;

public class Order extends Cars {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("WELCOME TO BW2-SHOPPER - Let's purchase your car \n");
		System.out.println("We have three possibity to offer you! \n");
		System.out.println("#######---- LandRover Velar, LandRover Discovery, LandRover Defender ----###### \n");
		System.out.println("Please type 0 to choose Velar, 1 to Discovery and 2 to Defender: ");
		int model = input.nextInt();
		System.out.println("Please select the category you would like, type 0 to Standart, 1 to Sport and 2 to Luxury");
		int category = input.nextInt();
		System.out.println(
				"Please select the color you would like, type 0 to 'black', 1 to 'white', 2 to 'red', 3 to 'silver' and 4 to 'blue'");
		int color = input.nextInt();
		System.out.println("\n");
		System.out.println("Would you like to add extra options in your car?, 0 yes or 1 no");
		int answer1 = input.nextInt();

		String extraOption = "";

		if (answer1 == 0) {
			System.out.println("There are these options that you can select: ");
			System.out.println(
					"0 = Interactive Driver Display, 1 = 360 Parking Aid, 2 = On-road Perfomance, 3 = Full-Road Perfomance");
			System.out.println(
					"Please select that would you like!, if would like more that one , please type in sequence number and using comma to separate");
			extraOption = input.next();
		}

		Cars obj = new Cars();
		obj.selectCarModel(model);
		obj.selectCategory(category);
		obj.selectCarColor(color);
		obj.selectExtraOption(extraOption);
		obj.carStatus();

		System.out.println("Would you like to change the basic option in your car?, 0 yes or 1 no");
		int answer2 = input.nextInt();

		int choose = 0;
		String value = "";
		String optional = "";

		while (answer2 == 0) {
			System.out.println("Which accessory would you like to change: ");
			System.out.println("0 = motor, 1 = wheels, 2 = airCondition, 3 = dashboardSystem, 4 = packSafety");
			int option = input.nextInt();

			if (option == 0) {
				System.out.println("Please type the motor you would like to change: ");
				System.out.println("0 = 2.0 Turbo Charge, 1 = 3.5 Turbo Charge, 2 = 4.5 Turbo Charge");
				choose = input.nextInt();
				optional = "motor";
				if (choose == 0) {
					value = "2.0 Turbo Charge";
				} else if (choose == 1) {
					value = "3.5 Turbo Charge";
				} else if (choose == 2) {
					value = "4.5 Turbo Charge";
				} else {
					System.out.println("Sorry, but you cannot change item without to be inside the list");
				}
				obj.selectIndividualOption(optional, value);
				System.out.println("Would you like to change one more item?, 0 yes or 1 no");
				answer2 = input.nextInt();
			} else if (option == 1) {
				System.out.println("Please type size wheels you would like to change: ");
				System.out.println("0 = 17, 1 = 19, 2 = 21");
				choose = input.nextInt();
				optional = "wheels";
				if (choose == 0) {
					value = "17";
				} else if (choose == 1) {
					value = "19";
				} else if (choose == 2) {
					value = "21";
				} else {
					System.out.println("Sorry, but you cannot change item without to be inside the list");
				}
				obj.selectIndividualOption(optional, value);
				System.out.println("Would you like to change one more item?, 0 yes or 1 no");
				answer2 = input.nextInt();
			} else if (option == 2) {
				System.out.println("Please type airCondition you would like to change: ");
				System.out.println("0 = dual zone, 1 = quad zone, 2 = mult zone");
				choose = input.nextInt();
				optional = "airCondition";
				if (choose == 0) {
					value = "dual zone";
				} else if (choose == 1) {
					value = "quad zone";
				} else if (choose == 2) {
					value = "mult zone";
				} else {
					System.out.println("Sorry, but you cannot change item without to be inside the list");
				}
				obj.selectIndividualOption(optional, value);
				System.out.println("Would you like to change one more item?, 0 yes or 1 no");
				answer2 = input.nextInt();
			} else if (option == 3) {
				System.out.println("Please type dashboardSystem you would like to change: ");
				System.out.println("0 = Incontrol, 1 = Touch Pro, 2 = Touch Pro + Audio system 'Meridia' ");
				choose = input.nextInt();
				optional = "dashboardSystem";
				if (choose == 0) {
					value = "Incontrol";
				} else if (choose == 1) {
					value = "Touch Pro";
				} else if (choose == 2) {
					value = "Touch Pro + Audio system 'Meridia'";
				} else {
					System.out.println("Sorry, but you cannot change item without to be inside the list");
				}
				obj.selectIndividualOption(optional, value);
				System.out.println("Would you like to change one more item?, 0 yes or 1 no");
				answer2 = input.nextInt();
			} else if (option == 4) {
				System.out.println("Please type pack Safety you would like to change: ");
				System.out.println("0 = basic, 1 = advance, 2 = prime");
				choose = input.nextInt();
				optional = "packSafety";
				if (choose == 0) {
					value = "basic";
				} else if (choose == 1) {
					value = "adavance";
				} else if (choose == 2) {
					value = "prime";
				} else {
					System.out.println("Sorry, but you cannot change item without to be inside the list");
				}
				obj.selectIndividualOption(optional, value);
				System.out.println("Would you like to change one more item?, 0 yes or 1 no");
				answer2 = input.nextInt();
			}

		}

		obj.carStatus();
		input.close();

	}

}
