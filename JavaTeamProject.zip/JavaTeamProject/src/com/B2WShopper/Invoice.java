package com.B2WShopper;

public class Invoice extends Cars {
	public void calculateInvoice() {

	}

	public void calculateIncoiceForMoreCar() {

	}

}
