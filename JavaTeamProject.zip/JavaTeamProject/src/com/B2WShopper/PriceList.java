package com.B2WShopper;

public class PriceList extends Cars {
	/**
	 * Create price lists for 3 model cars inside each list should be 3 options
	 * minimum price
	 */
}
